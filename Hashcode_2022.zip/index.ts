import fs from 'fs';
import {User, Project, Skill} from './models';

const inputs = [
    'a_an_example.in.txt',
    'b_better_start_small.in.txt',
    'c_collaboration.in.txt',
    'd_dense_schedule.in.txt',
    'e_exceptional_skills.in.txt',
    'f_find_great_mentors.in.txt'
]
const inputIndex = 2;
const data = fs.readFileSync('./input_data/' + inputs[inputIndex], {encoding:'utf8', flag:'r'});

const lines = data.split('\n');
const numUsers = parseInt(lines[0].split(' ')[0]);
const numProjects = parseInt(lines[0].split(' ')[1]);

let lineIndex = 1;
const users: User[] = [];
while(users.length < numUsers){
    let line = lines[lineIndex++];
    const userName = line.split(' ')[0];
    const numSkills = parseInt(line.split(' ')[1]);
    
    const skills:Skill[] = [];
    for(let skillIndex=0; skillIndex<numSkills; skillIndex++){
        line = lines[lineIndex++];
        const skillName = line.split(' ')[0];
        const skillLevel = parseInt(line.split(' ')[1]);
        skills.push(new Skill(skillName, skillLevel));
    }

    users.push(new User(userName, skills));
}
const allUsers = users.slice();

let projects: Project[] = [];
while(projects.length < numProjects){
    let line = lines[lineIndex++];
    const projectName = line.split(' ')[0];
    const duration = parseInt(line.split(' ')[1]);
    const score = parseInt(line.split(' ')[2]);
    const bestBefore = parseInt(line.split(' ')[3]);
    const numRoles = parseInt(line.split(' ')[4]);
    
    const roles:Skill[] = [];
    for(let skillIndex=0; skillIndex<numRoles; skillIndex++){
        line = lines[lineIndex++];
        const skillName = line.split(' ')[0];
        const skillLevel = parseInt(line.split(' ')[1]);
        roles.push(new Skill(skillName, skillLevel));
    }

    projects.push(new Project(projectName, duration, score, bestBefore, roles));
}
let allProjects = projects.slice();

let outputStr = '';
let doneProjects = 0;

let dayIndex = 0;
while(projects.length > 0){
    simulate();
}
fs.writeFileSync( `results/${inputs[inputIndex].split('.')[0]}.txt`, doneProjects + '\n' + outputStr);
// console.log(JSON.stringify(allProjects, null, 2));
   
function simulate(){
    projects.map(el => el.evaluate(dayIndex));
    projects.sort((a,b) => b.lastEval - a.lastEval);

    projects.map(el => el.assign(users, dayIndex));

    projects.map(el => {
        if(el.working && dayIndex >= el.workUntil) {
            el.complete();
            outputStr += el.name + '\n' + el.assignments.map(assignment => assignment.user.name).join(' ') + '\n'  
            doneProjects++;
        }
    });

    projects = projects.filter(el => {
        return el.working || (!el.completed && el.lastEval > 0);
    });
    dayIndex++;
}