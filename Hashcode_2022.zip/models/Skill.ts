export default class Skill {
    name: string;
    skillLevel: number;

    constructor(name: string, skillLevel: number){
        this.name = name;
        this.skillLevel = skillLevel;
    }
}