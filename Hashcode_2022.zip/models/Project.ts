import { User } from ".";
import Skill from "./Skill";

interface IAssignment{
    user: User;
    role: Skill;
}
export default class Project {
    name: string;
    duration: number;
    score: number;
    bestBefore: number;
    skills: Skill[];

    lastEval: number = 0;

    working: boolean = false;
    workUntil: number = 0;
    assignments: IAssignment[] = [];
        
    completed: boolean = false;

    constructor(name: string, duration: number, score: number, bestBefore: number, skill: Skill[]) {
        this.name = name;
        this.duration = duration;
        this.score = score; 
        this.bestBefore = bestBefore;
        this.skills = skill;
    }

    evaluate(dayIndex: number){
        let daysRemaining = this.bestBefore + this.score - dayIndex;
        let score = (this.score + daysRemaining) / (this.duration);

        let difficulty = 0;
        this.skills.map(el => difficulty += el.skillLevel);

        return this.lastEval = score / difficulty;
    }

    //check if user can be assigned to a role
    canAssign(user: User, role: Skill){
        if(user.working) return false;

        let retVal = false;
        user.skills.map(skill => {
            if(skill.name == role.name && skill.skillLevel >= role.skillLevel){
                retVal = true;
            }
        });
        return retVal;
    }


    //check if users can work on all the roles
    assign(users: User[], dayIndex: number){
        if(this.working) return false;

        let assignable = 0;
        
        this.skills.map(role => {
            users.map(user => {
                if(this.canAssign(user, role)){
                    this.assignments.push({user: user, role: role});
                    user.assign(dayIndex + this.duration);
                    assignable++;
                }
            })
        });

        if(assignable >= this.skills.length){
            this.working = true;
            this.workUntil = dayIndex + this.duration -1;
            return true;
        }else{
            this.assignments.map(el => el.user.unassign());
            this.assignments = [];
            return false;
        }
    }

    complete(){
        this.working = false;
        this.completed = true;
        this.assignments.map(assignment => {
            assignment.user.working = false;
            const skill = assignment.user.skills.find((skill) => skill.name == assignment.role.name);
            if(skill && skill.skillLevel <= assignment.role.skillLevel){
                skill.skillLevel++;
            }
        });
    }
}